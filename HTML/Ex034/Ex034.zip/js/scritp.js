const myName = document.querySelector('.cabecalho h1');
myName.style.fontSize = '2.4rem';

const title_1 = document.querySelector('.conteiner h2');
title_1.style.fontSize = '1.8rem';

const l = document.querySelector('div .lista');
l.style.marginLeft = '20px';

const l0 =document.querySelector(' div .lista0');
l0.style.marginLeft ='20px';

const photo0= document.querySelector('section .photo1');
photo0.style.width=' 275px';
photo0.style.height='304px';
photo0.style.marginRight='20pix';

const photo1= document.querySelector('section .photo2');
photo1.style.width=' 275px';
photo1.style.height='304px';
photo1.style.marginRight='20pix';

const root =document.querySelector('body .root');
root.style.displey ='flex';
root.style.width='100%';
root.style.maxWidth='900px';
root.style.flexDirection='column';
root.style.alignItems='center';

const perfil0 =document.querySelector('header .perfil');
perfil0.style.displey='flex';
perfil0.style.width='80px';
perfil0.style.height='100px';

const header1=document.querySelector('header .cabecalho');
header1.style.displey='flex';
header1.style.flexDirection='column';
header1.style.alignItems='center';
header1.style.justifyContent='center';
header1.style.width='600px';
header1.style.marginTop='0px';


const body0=document.querySelector('html body');
body0.style.displey='flex';
body0.style.flexDirection='column';
body0.style.alignItems='center';
body0.style.justifyContent='center';
/* body0.styele.fontSize='20px';*/
body0.style.fontFamily="'futura'",'sans-serif';
body0.style.width='100vw';
body0.style.height='100vw';
body0.style.overflowX='hidden';

const final=document.querySelector('footer p');
final.style.marginTop='50px';
final.style.fontSize='1rem';
     
/* const header0=document.querySelector('.root .cabeca')
header0.style.displey='flex';
header0.style.flexDirection='row';
header0.style.alignItems='center';
header0.style.justifyContent='center';*/
   