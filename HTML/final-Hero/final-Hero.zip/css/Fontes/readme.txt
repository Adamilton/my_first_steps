Thanks for downloading "infected" by Allen Chiu.
 
I love to see my fonts being used, please email me if you are interested in using my font. You can send your inquiry to: allencdesign@gmail.com
 
 
*** Please note it is strictly prohibited to use my font for use without my consent in writing.
 
 
 
Allen Chiu
 
Email: allencdesign@gmail.com
