function array(..._arr){
    return _arr;
}

const test = array(1,5,6,8,9,12,64)

console.log(Array.isArray(test));
